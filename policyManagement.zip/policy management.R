

# Define PolicyHolder class
PolicyHolder <- R6::R6Class(
  "PolicyHolder",
  public = list(
    initialize = function(id, name, status = "Active") {
      self$id <- id
      self$name <- name
      self$status <- status
      self$products <- character()
    },
    suspend = function() {
      self$status <- "Suspended"
    },
    reactivate = function() {
      self$status <- "Active"
    },
    display_details = function() {
      cat(paste0("Policyholder ID: ", self$id, "\n"))
      cat(paste0("Name: ", self$name, "\n"))
      cat(paste0("Status: ", self$status, "\n"))
      cat("Products:\n")
      for (product in self$products) {
        cat(paste0(" - ", product, "\n"))
      }
    }
  )
)


# Define Product class
Product <- R6::R6Class(
  "Product",
  public = list(
    initialize = function(code, name, price) {
      self$code <- code
      self$name <- name
      self$price <- price
      self$status <- "Active"
    },
    update_price = function(new_price) {
      self$price <- new_price
    },
    suspend = function() {
      self$status <- "Suspended"
    },
    display_details = function() {
      cat(paste0("Product Code: ", self$code, "\n"))
      cat(paste0("Name: ", self$name, "\n"))
      cat(paste0("Price: $", self$price, "\n"))
      cat(paste0("Status: ", self$status, "\n"))
    }
  )
)


# Define Payment class
Payment <- R6::R6Class(
  "Payment",
  public = list(
    initialize = function(policyholder, amount, date) {
      self$policyholder <- policyholder
      self$amount <- amount
      self$date <- date
    },
    process_payment = function() {
      cat(paste0("Payment of $", self$amount, " processed for ", self$policyholder$name, " on ", self$date, "\n"))
    },
    send_payment_reminder = function() {
      cat(paste0("Reminder: Payment of $", self$amount, " due for ", self$policyholder$name, "\n"))
    },
    apply_penalty = function() {
      cat(paste0("Penalty applied: Payment for ", self$policyholder$name, " is overdue\n"))
    }
  )
)


# Create products
product1 <- Product$new("P001", "Product A", 100)
product2 <- Product$new("P002", "Product B", 150)


# Create policyholders
policyholder1 <- PolicyHolder$new(1, "Mike paul")
policyholder2 <- PolicyHolder$new(2, "Rose Bean")


# Add products to policyholders
policyholder1$products <- c(policyholder1$products, product1$name)
policyholder2$products <- c(policyholder2$products, product2$name)


# Display account details
policyholder1$display_details()
policyholder2$display_details()


# Process payments
payment1 <- Payment$new(policyholder1, 100, "2024-04-09")
payment2 <- Payment$new(policyholder2, 150, "2024-04-09")
payment1$process_payment()
payment2$send_payment_reminder()
payment2$apply_penalty()





